/* global React, ReactDOM, useTweaks, TweaksPanel, TweakSection, TweakRadio, TweakToggle, I18N, Calendar, StockCard, DetailPanel, fmtPct */
const { useState, useMemo, useEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "cardStyle": "default",
  "density": "comfy",
  "theme": "light",
  "accent": "#2f6dff"
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [lang, setLang] = useState("ko");
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [selectedDate, setSelectedDate] = useState("2026-04-30");
  const [activeStock, setActiveStock] = useState(null);

  const data = window.APP_DATA;
  const t = I18N[lang];

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", tweaks.theme);
    document.documentElement.setAttribute("data-cardstyle", tweaks.cardStyle);
    document.documentElement.setAttribute("data-density", tweaks.density);
    document.documentElement.style.setProperty("--accent", tweaks.accent);
  }, [tweaks]);

  const filteredStocks = useMemo(() => {
    return data.stocks.filter((s) => {
      if (filter !== "all" && s.sentiment !== filter) return false;
      if (search) {
        const q = search.toLowerCase();
        if (!s.ticker.toLowerCase().includes(q) && !s.name.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [filter, search]);

  return (
    <>
      {/* NAV */}
      <nav className="nav">
        <div className="nav-inner">
          <div className="brand">
            <div className="brand-dot">分</div>
            <span>분석</span>
          </div>
          <div className="nav-links">
            <a className="nav-link active" href="#news">{t.nav_news}</a>
            <a className="nav-link" href="#models">{t.nav_models}</a>
            <a className="nav-link" href="#tickers">{t.nav_tickers}</a>
            <a className="nav-link" href="#about">{t.nav_about}</a>
          </div>
          <div className="nav-spacer" />
          <div className="nav-actions">
            <div className="lang-toggle">
              <button className={lang === "ko" ? "active" : ""} onClick={() => setLang("ko")}>KO</button>
              <button className={lang === "en" ? "active" : ""} onClick={() => setLang("en")}>EN</button>
            </div>
            <button className="icon-btn" onClick={() => setTweak("theme", tweaks.theme === "light" ? "dark" : "light")} aria-label="theme">
              {tweaks.theme === "light" ? (
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M13 9.5A5.5 5.5 0 0 1 6.5 3a5.5 5.5 0 1 0 6.5 6.5z"/></svg>
              ) : (
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="8" cy="8" r="3"/><path d="M8 1v2M8 13v2M1 8h2M13 8h2M3 3l1.5 1.5M11.5 11.5L13 13M3 13l1.5-1.5M11.5 4.5L13 3"/></svg>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* HEADLINE TICKER */}
      <div className="headline-ticker">
        <div className="headline-track">
          {[...data.headlines, ...data.headlines].map((h, i) => (
            <span key={i} className="headline-item">
              <span className="headline-tick">{h.ticker}</span>
              {lang === "ko" ? h.ko : h.en}
              <span className="headline-time">· {h.time}</span>
            </span>
          ))}
        </div>
      </div>

      <div className="container">
        {/* HERO */}
        <section className="hero" id="news">
          <div className="hero-eyebrow">{t.eyebrow(data.meta.index)}</div>
          <h1 className="hero-title">{t.hero_title}</h1>
          <p className="hero-sub">{t.hero_sub}</p>

          <div style={{ display: "grid", gridTemplateColumns: "320px 1fr", gap: 20, alignItems: "stretch" }}>
            <Calendar selected={selectedDate} onSelect={setSelectedDate} lang={lang} />
            <div className="hero-strip">
              <div className="strip-cell">
                <div className="strip-label">{t.strip_news}</div>
                <div className="strip-value strip-tone-neutral">
                  {data.meta.newsCount}<span className="unit">{lang === "ko" ? "건" : ""}</span>
                </div>
                <div style={{ fontSize: 12, color: "var(--ink-3)" }}>
                  {lang === "ko" ? `전체 ${data.meta.totalScanned}종목 분석` : `across ${data.meta.totalScanned} tickers`}
                </div>
              </div>
              <div className="strip-cell">
                <div className="strip-label">{t.strip_bearish}</div>
                <div className="strip-value strip-tone-up">{data.meta.bearish}</div>
                <div style={{ fontSize: 12, color: "var(--ink-3)" }}>{lang === "ko" ? "▲ 매수 검토" : "▲ buy candidates"}</div>
              </div>
              <div className="strip-cell">
                <div className="strip-label">{t.strip_bullish}</div>
                <div className="strip-value strip-tone-down">{data.meta.bullish}</div>
                <div style={{ fontSize: 12, color: "var(--ink-3)" }}>{lang === "ko" ? "▼ 매도 검토" : "▼ sell candidates"}</div>
              </div>
              <div className="strip-cell">
                <div className="strip-label">{t.strip_neutral}</div>
                <div className="strip-value strip-tone-neutral">{data.meta.neutral}</div>
                <div style={{ fontSize: 12, color: "var(--ink-3)" }}>{lang === "ko" ? "관망" : "watch"}</div>
              </div>
            </div>
          </div>
        </section>

        {/* SECTION HEAD + FILTERS */}
        <section className="section">
          <div className="section-head">
            <div>
              <h2 className="section-title">{t.section_stocks}</h2>
              <p className="section-sub">{t.section_stocks_sub}</p>
            </div>
          </div>

          <div className="filter-bar">
            <button className={`chip ${filter === "all" ? "active" : ""}`} onClick={() => setFilter("all")}>
              {t.filter_all} <span style={{ opacity: 0.6, fontFamily: "Inter" }}>{data.stocks.length}</span>
            </button>
            <button className={`chip ${filter === "bearish" ? "active" : ""}`} onClick={() => setFilter("bearish")}>
              <span className="chip-dot bearish"></span>{t.filter_bear} <span style={{ opacity: 0.6, fontFamily: "Inter" }}>{data.stocks.filter(s=>s.sentiment==="bearish").length}</span>
            </button>
            <button className={`chip ${filter === "bullish" ? "active" : ""}`} onClick={() => setFilter("bullish")}>
              <span className="chip-dot bullish"></span>{t.filter_bull} <span style={{ opacity: 0.6, fontFamily: "Inter" }}>{data.stocks.filter(s=>s.sentiment==="bullish").length}</span>
            </button>
            <button className={`chip ${filter === "neutral" ? "active" : ""}`} onClick={() => setFilter("neutral")}>
              <span className="chip-dot neutral"></span>{t.filter_neu} <span style={{ opacity: 0.6, fontFamily: "Inter" }}>{data.stocks.filter(s=>s.sentiment==="neutral").length}</span>
            </button>
            <div style={{ flex: 1 }} />
            <input
              className="search-input"
              placeholder={t.search_ph}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <div className="stock-list">
            {filteredStocks.length > 0 ? filteredStocks.map((s) => (
              <StockCard key={s.ticker} stock={s} lang={lang} onClick={setActiveStock} />
            )) : (
              <div style={{ padding: 60, textAlign: "center", color: "var(--ink-3)" }}>
                {lang === "ko" ? "검색 결과가 없습니다." : "No results."}
              </div>
            )}
          </div>
        </section>

        {/* ABOUT teaser */}
        <section className="section" id="about">
          <div className="section-head">
            <div>
              <h2 className="section-title">{lang === "ko" ? "분석은 어떻게 동작하나요?" : "How it works"}</h2>
              <p className="section-sub">
                {lang === "ko"
                  ? "여섯 가지 신호를 결합해 매일 시장 심리를 만들어냅니다."
                  : "Six independent signals combined into a daily sentiment view."}
              </p>
            </div>
          </div>
          <div className="about-grid">
            <div className="about-tile">
              <div className="about-tile-icon">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M2 14 L6 8 L9 11 L16 4"/><circle cx="6" cy="8" r="1.2" fill="currentColor"/><circle cx="9" cy="11" r="1.2" fill="currentColor"/></svg>
              </div>
              <h3>{lang === "ko" ? "5개 시계열 모델" : "5 time-series models"}</h3>
              <p>{lang === "ko" ? "XGBoost, PPO 강화학습, TimesFM, Chronos, Moirai가 각자 독립적으로 방향성을 예측합니다." : "XGBoost, PPO·RL, TimesFM, Chronos, and Moirai each predict direction independently."}</p>
            </div>
            <div className="about-tile">
              <div className="about-tile-icon">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M3 5 H15 M3 9 H12 M3 13 H10"/></svg>
              </div>
              <h3>{lang === "ko" ? "뉴스 + 소문" : "News + community"}</h3>
              <p>{lang === "ko" ? "주요 매체의 헤드라인과 투자 커뮤니티의 소문 신호(BUY/SELL/HOLD)를 LLM이 종합합니다." : "LLM synthesizes major headlines and community BUY/SELL/HOLD chatter."}</p>
            </div>
            <div className="about-tile">
              <div className="about-tile-icon">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" strokeWidth="1.6"><circle cx="9" cy="9" r="6"/><path d="M9 5 V9 L11.5 11"/></svg>
              </div>
              <h3>{lang === "ko" ? "매일 자동 갱신" : "Daily refresh"}</h3>
              <p>{lang === "ko" ? "S&P 500 전 종목을 매일 장 마감 1시간 전 자동으로 스캔합니다." : "All S&P 500 names auto-scanned 1 hour before market close, every trading day."}</p>
            </div>
          </div>
        </section>

        {/* FOOTER */}
        <footer className="footer">
          <div className="footer-inner">
            <div>
              <div style={{ fontWeight: 700, color: "var(--ink)", marginBottom: 6 }}>분석 · Bunseok</div>
              <div style={{ fontSize: 12, color: "var(--ink-4)" }}>{lang === "ko" ? "매일 무료로 제공됩니다." : "Free, every trading day."}</div>
            </div>
            <p className="footer-disclaimer">{t.footer_disclaimer}</p>
          </div>
        </footer>
      </div>

      {/* DETAIL */}
      {activeStock && <DetailPanel stock={activeStock} lang={lang} onClose={() => setActiveStock(null)} />}

      {/* TWEAKS PANEL */}
      <TweaksPanel title="Tweaks">
        <TweakSection title={lang === "ko" ? "카드 스타일" : "Card style"}>
          <TweakRadio
            value={tweaks.cardStyle}
            onChange={(v) => setTweak("cardStyle", v)}
            options={[
              { value: "default", label: lang === "ko" ? "기본" : "Default" },
              { value: "minimal", label: lang === "ko" ? "미니멀" : "Minimal" },
              { value: "editorial", label: lang === "ko" ? "에디토리얼" : "Editorial" },
            ]}
          />
        </TweakSection>
        <TweakSection title={lang === "ko" ? "정보 밀도" : "Density"}>
          <TweakRadio
            value={tweaks.density}
            onChange={(v) => setTweak("density", v)}
            options={[
              { value: "comfy", label: lang === "ko" ? "여유" : "Comfy" },
              { value: "compact", label: lang === "ko" ? "조밀" : "Compact" },
            ]}
          />
        </TweakSection>
        <TweakSection title={lang === "ko" ? "테마" : "Theme"}>
          <TweakRadio
            value={tweaks.theme}
            onChange={(v) => setTweak("theme", v)}
            options={[
              { value: "light", label: lang === "ko" ? "라이트" : "Light" },
              { value: "dark", label: lang === "ko" ? "다크" : "Dark" },
            ]}
          />
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
