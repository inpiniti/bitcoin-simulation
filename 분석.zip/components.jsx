/* global React, ReactDOM */
const { useState, useMemo, useEffect, useRef } = React;

/* ─────────── i18n ─────────── */
const I18N = {
  ko: {
    nav_news: "뉴스 분석",
    nav_models: "AI 모델",
    nav_tickers: "티커",
    nav_about: "About",
    eyebrow: (idx) => `${idx} · 뉴스 분석`,
    hero_title: "오늘의 시장 심리",
    hero_sub: "AI가 503개 종목의 뉴스·소문·시계열 신호를 종합해 매일 시장 심리를 분석합니다. 무료로 누구나.",
    strip_news: "뉴스 분석",
    strip_bearish: "낙관 종목",
    strip_bullish: "비관 종목",
    strip_neutral: "중립 종목",
    section_stocks: "분석 종목",
    section_stocks_sub: "신뢰도가 높은 순으로 보여드려요. 종목을 클릭하면 상세 분석을 볼 수 있어요.",
    filter_all: "전체",
    filter_bear: "낙관",
    filter_bull: "비관",
    filter_neu: "중립",
    search_ph: "종목명, 티커 검색…",
    confidence: "신뢰도",
    bullish: "낙관",
    bearish: "비관",
    neutral: "중립",
    detail_summary: "AI 종합 의견",
    detail_rumor: "커뮤니티 소문",
    detail_models: "5개 모델 + 소문 신호",
    detail_chart: "30일 추이",
    detail_news: "관련 뉴스",
    today_strip: (n) => `오늘 ${n}건의 뉴스를 분석했습니다`,
    consensus: (c) => `동의 ${c}`,
    cta_about: "더 알아보기",
    footer_disclaimer: "투자 자문이 아닙니다. AI 분석 결과는 참고용으로만 사용하시고, 모든 투자 판단은 본인의 책임 하에 이루어져야 합니다.",
    rank: "순위",
    sentiment_label: "심리",
    nodata: "이 날짜에는 분석 데이터가 없습니다.",
  },
  en: {
    nav_news: "News",
    nav_models: "AI Models",
    nav_tickers: "Tickers",
    nav_about: "About",
    eyebrow: (idx) => `${idx} · News Analysis`,
    hero_title: "Today's Market Sentiment",
    hero_sub: "AI synthesizes news, community chatter, and time-series signals across 503 tickers — every day, free for everyone.",
    strip_news: "News analyzed",
    strip_bearish: "Bearish names",
    strip_bullish: "Bullish names",
    strip_neutral: "Neutral",
    section_stocks: "Tickers analyzed",
    section_stocks_sub: "Sorted by confidence. Click any ticker for the full breakdown.",
    filter_all: "All",
    filter_bear: "Bearish",
    filter_bull: "Bullish",
    filter_neu: "Neutral",
    search_ph: "Search ticker or name…",
    confidence: "confidence",
    bullish: "Bullish",
    bearish: "Bearish",
    neutral: "Neutral",
    detail_summary: "AI synthesis",
    detail_rumor: "Community signal",
    detail_models: "5 models + rumors",
    detail_chart: "30-day trend",
    detail_news: "Related news",
    today_strip: (n) => `${n} news items analyzed today`,
    consensus: (c) => `consensus ${c}`,
    cta_about: "Learn more",
    footer_disclaimer: "Not investment advice. AI outputs are for reference only; investment decisions remain your own responsibility.",
    rank: "Rank",
    sentiment_label: "Signal",
    nodata: "No analysis data for this date.",
  },
};

/* ─────────── helpers ─────────── */
const fmtPct = (n) => (n >= 0 ? `+${n.toFixed(2)}%` : `${n.toFixed(2)}%`);
const fmtPrice = (n) => `$${n.toFixed(2)}`;
const arrow = (dir) => (dir === "up" ? "▲" : dir === "down" ? "▼" : "–");

/* Sparkline svg */
function Sparkline({ data, tone, height = 56, showArea = true }) {
  const w = 100, h = 100;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const pts = data.map((v, i) => [
    (i / (data.length - 1)) * w,
    h - ((v - min) / range) * h * 0.85 - h * 0.075,
  ]);
  const path = pts.map(([x, y], i) => (i === 0 ? `M${x} ${y}` : `L${x} ${y}`)).join(" ");
  const area = `${path} L${w} ${h} L0 ${h} Z`;
  const stroke =
    tone === "bullish" ? "var(--down)" : tone === "bearish" ? "var(--up)" : "var(--ink-3)";
  const fill =
    tone === "bullish" ? "var(--down-soft)" : tone === "bearish" ? "var(--up-soft)" : "var(--neutral-soft)";
  return (
    <div className="spark-wrap" style={{ height }}>
      <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
        {showArea && <path d={area} fill={fill} opacity="0.6" />}
        <path d={path} fill="none" stroke={stroke} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
      </svg>
    </div>
  );
}

/* Detailed chart with grid + axis */
function DetailChart({ data, tone }) {
  const w = 600, h = 180;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const pts = data.map((v, i) => [
    (i / (data.length - 1)) * w,
    h - ((v - min) / range) * h * 0.8 - h * 0.1,
  ]);
  const path = pts.map(([x, y], i) => (i === 0 ? `M${x} ${y}` : `L${x} ${y}`)).join(" ");
  const area = `${path} L${w} ${h} L0 ${h} Z`;
  const stroke =
    tone === "bullish" ? "var(--down)" : tone === "bearish" ? "var(--up)" : "var(--ink-3)";
  const fill =
    tone === "bullish" ? "var(--down-soft)" : tone === "bearish" ? "var(--up-soft)" : "var(--neutral-soft)";
  return (
    <div className="detail-chart">
      <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
        {[0.25, 0.5, 0.75].map((p, i) => (
          <line key={i} x1="0" x2={w} y1={h * p} y2={h * p} stroke="var(--border)" strokeWidth="1" vectorEffect="non-scaling-stroke" />
        ))}
        <path d={area} fill={fill} opacity="0.6" />
        <path d={path} fill="none" stroke={stroke} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
        <circle cx={pts[pts.length - 1][0]} cy={pts[pts.length - 1][1]} r="4" fill={stroke} />
      </svg>
    </div>
  );
}

/* ─────────── Calendar ─────────── */
function Calendar({ selected, onSelect, lang }) {
  const [view, setView] = useState({ y: 2026, m: 4 });
  const dowKo = ["일", "월", "화", "수", "목", "금", "토"];
  const dowEn = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const dow = lang === "ko" ? dowKo : dowEn;
  const monthKo = `${view.m}월`;
  const monthEn = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][view.m - 1];
  const firstDow = new Date(view.y, view.m - 1, 1).getDay();
  const daysInMonth = new Date(view.y, view.m, 0).getDate();
  const prevMonthDays = new Date(view.y, view.m - 1, 0).getDate();
  const cells = [];
  for (let i = firstDow - 1; i >= 0; i--) {
    cells.push({ day: prevMonthDays - i, muted: true });
  }
  for (let d = 1; d <= daysInMonth; d++) {
    cells.push({ day: d, date: `${view.y}-${String(view.m).padStart(2, "0")}-${String(d).padStart(2, "0")}`, hasData: d <= 30 });
  }
  while (cells.length < 42) {
    cells.push({ day: cells.length - daysInMonth - firstDow + 1, muted: true });
  }
  const navMonth = (delta) => {
    let nm = view.m + delta, ny = view.y;
    if (nm < 1) { nm = 12; ny--; }
    if (nm > 12) { nm = 1; ny++; }
    setView({ y: ny, m: nm });
  };
  return (
    <div className="cal-wrap">
      <div className="cal-head">
        <div className="cal-nav">
          <button onClick={() => navMonth(-1)} aria-label="prev">
            <svg width="14" height="14" viewBox="0 0 14 14"><path d="M9 3 L5 7 L9 11" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
        </div>
        <div>{lang === "ko" ? `${view.y}년 ${monthKo}` : `${monthEn} ${view.y}`}</div>
        <div className="cal-nav">
          <button onClick={() => navMonth(1)} aria-label="next">
            <svg width="14" height="14" viewBox="0 0 14 14"><path d="M5 3 L9 7 L5 11" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
        </div>
      </div>
      <div className="cal-grid">
        {dow.map((d, i) => (
          <div key={d} className={`cal-dow ${i === 0 ? "sun" : i === 6 ? "sat" : ""}`}>{d}</div>
        ))}
        {cells.map((c, i) => {
          const isSelected = c.date === selected;
          const isToday = c.date === "2026-04-30";
          return (
            <div
              key={i}
              className={`cal-day ${c.muted ? "muted" : ""} ${c.hasData ? "has-data" : ""} ${isSelected ? "selected" : ""} ${isToday && !isSelected ? "today" : ""}`}
              onClick={() => !c.muted && c.date && onSelect(c.date)}
            >
              {c.day}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ─────────── Stock card ─────────── */
function StockCard({ stock, lang, onClick }) {
  const t = I18N[lang];
  const summary = lang === "ko" ? stock.summary_ko : stock.summary_en;
  const rumorNote = lang === "ko" ? stock.rumor_note_ko : stock.rumor_note_en;
  return (
    <div className="stock-card" onClick={() => onClick(stock)}>
      <div className="rank-badge">{String(stock.rank).padStart(2, "0")}</div>
      <div className="stock-main">
        <div className="stock-head">
          <span className="stock-ticker">{stock.ticker}</span>
          <span className="stock-name">{stock.name}</span>
          <span className="sector-badge">{stock.sector}</span>
          <span className="consensus-pill">{t.consensus(stock.consensus)}</span>
        </div>
        <p className="stock-summary">{summary}</p>
        <div className="stock-rumor">
          <span className={`rumor-tag ${stock.rumor}`}>{stock.rumor}</span>
          <span className="rumor-text">{rumorNote}</span>
        </div>
        <div className="models-row">
          {Object.entries(stock.models).map(([k, v]) => (
            <span key={k} className={`model-chip ${v}`}>
              <span className="model-arrow">{arrow(v)}</span>
              {k}
            </span>
          ))}
        </div>
      </div>
      <div className="stock-side">
        <Sparkline data={stock.spark} tone={stock.sentiment} />
        <div className="spark-meta">
          <span className="price">{fmtPrice(stock.price)}</span>
          <span className={`pct ${stock.changePct >= 0 ? "up" : "down"}`}>{fmtPct(stock.changePct)}</span>
        </div>
      </div>
      <div className="stock-score">
        <div className={`score-num ${stock.sentiment}`}>{stock.confidence}<span style={{fontSize:18, opacity:0.7}}>%</span></div>
        <div className="score-label">{t.confidence}</div>
        <div className={`sentiment-pill ${stock.sentiment}`}>
          {stock.sentiment === "bullish" ? "▲" : stock.sentiment === "bearish" ? "▼" : "—"}
          {t[stock.sentiment]}
        </div>
      </div>
    </div>
  );
}

/* ─────────── Detail panel ─────────── */
function DetailPanel({ stock, lang, onClose }) {
  const t = I18N[lang];
  const summary = lang === "ko" ? stock.summary_ko : stock.summary_en;
  const rumorNote = lang === "ko" ? stock.rumor_note_ko : stock.rumor_note_en;
  const models = window.APP_DATA.models;
  const headlines = window.APP_DATA.headlines.filter((h) => h.ticker === stock.ticker || Math.random() < 0.4).slice(0, 5);

  useEffect(() => {
    const onEsc = (e) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onEsc);
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", onEsc); document.body.style.overflow = ""; };
  }, [onClose]);

  return (
    <div className="detail-overlay" onClick={onClose}>
      <div className="detail-panel" onClick={(e) => e.stopPropagation()}>
        <div className="detail-head">
          <div style={{ fontSize: 13, color: "var(--ink-3)", fontWeight: 500 }}>
            #{String(stock.rank).padStart(2, "0")} · {stock.sector}
          </div>
          <button className="detail-close" onClick={onClose} aria-label="close">
            <svg width="14" height="14" viewBox="0 0 14 14"><path d="M3 3 L11 11 M11 3 L3 11" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></svg>
          </button>
        </div>
        <div className="detail-body">
          <div className="detail-ticker-row">
            <span className="detail-ticker">{stock.ticker}</span>
            <span className="detail-name">{stock.name}</span>
          </div>
          <div className="detail-price-row">
            <span className="detail-price">{fmtPrice(stock.price)}</span>
            <span className={`detail-pct ${stock.changePct >= 0 ? "up" : "down"}`}>{fmtPct(stock.changePct)}</span>
            <span className={`sentiment-pill ${stock.sentiment}`} style={{ marginLeft: "auto" }}>
              {stock.sentiment === "bullish" ? "▲" : stock.sentiment === "bearish" ? "▼" : "—"}
              {t[stock.sentiment]} · {stock.confidence}%
            </span>
          </div>

          <div className="detail-block">
            <h3 className="detail-block-title">{t.detail_chart}</h3>
            <DetailChart data={stock.spark} tone={stock.sentiment} />
          </div>

          <div className="detail-block">
            <h3 className="detail-block-title">{t.detail_summary}</h3>
            <p className="detail-summary">{summary}</p>
            <div className="detail-rumor">
              <span className={`rumor-tag ${stock.rumor}`} style={{ flexShrink: 0 }}>{stock.rumor}</span>
              <div>
                <div style={{ fontSize: 11, color: "var(--ink-3)", marginBottom: 4, fontWeight: 600, letterSpacing: "0.04em", textTransform: "uppercase" }}>{t.detail_rumor}</div>
                {rumorNote}
              </div>
            </div>
          </div>

          <div className="detail-block">
            <h3 className="detail-block-title">{t.detail_models}</h3>
            <div className="detail-models">
              {models.map((m) => {
                const dir = stock.models[m.id] || "neutral";
                return (
                  <div key={m.id} className="model-tile">
                    <div className="model-tile-head">
                      <span className="model-tile-name">{m.name}</span>
                      <span className={`model-tile-arrow ${dir}`}>{arrow(dir)}</span>
                    </div>
                    <span className="model-tile-desc">{lang === "ko" ? m.desc_ko : m.desc_en}</span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="detail-block">
            <h3 className="detail-block-title">{t.detail_news}</h3>
            {headlines.length > 0 ? headlines.map((h, i) => (
              <div className="news-row" key={i}>
                <span className="ticker-mini">{h.ticker}</span>
                <span className="news-row-text">{lang === "ko" ? h.ko : h.en}</span>
                <span className="news-row-time">{h.time}</span>
              </div>
            )) : <div style={{ color: "var(--ink-3)", fontSize: 14 }}>—</div>}
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Sparkline, DetailChart, Calendar, StockCard, DetailPanel, I18N, fmtPct, fmtPrice, arrow });
